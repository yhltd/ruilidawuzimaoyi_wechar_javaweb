package com.myboot.pojo;

import java.io.Serializable;
import lombok.Data;

/**
 * product
 * @author 
 */
@Data
public class Product implements Serializable {
    private Integer id;

    /**
     * 商品名称
     */
    private String name;

    /**
     * 商品分类
     */
    private String type;

    /**
     * 单位
     */
    private String danwie;

    /**
     * 材质
     */
    private String caizhi;

    /**
     * 技术标准
     */
    private String jishuBiaozhun;

    /**
     * 质保等级
     */
    private String zhibaoDengji;

    /**
     * 备注
     */
    private String beizhu;

    private static final long serialVersionUID = 1L;
}