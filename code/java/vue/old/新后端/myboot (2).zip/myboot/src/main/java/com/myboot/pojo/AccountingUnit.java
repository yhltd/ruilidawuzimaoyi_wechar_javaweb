package com.myboot.pojo;

import lombok.Data;

@Data
public class AccountingUnit {
    private Integer aId;
    private String aName;
    private String aMor;
}
