package com.myboot.pojo;

import lombok.Data;

@Data
public class User {
    private String id;
    private String userName;
    private String adminName;
    private Integer money;
    private String localdiqv;
    private String localAddress;
    private String text;
    private String phone;
    private String localPhone;
    private String fatherName;
}
