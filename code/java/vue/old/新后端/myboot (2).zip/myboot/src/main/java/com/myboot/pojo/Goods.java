package com.myboot.pojo;

import lombok.Data;

@Data
public class Goods {
    private Integer gID;
    private String gName;
    private String gFenl;
    private String gUnit;
    private String gMaterial;
    private String gTechnology;
    private String gLevel;
    private String gText;
}
