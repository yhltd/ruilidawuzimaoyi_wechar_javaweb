<template>

</template>

<script>
export default {
  name: "JiaGeLevel"
}
</script>

<style scoped>

</style>