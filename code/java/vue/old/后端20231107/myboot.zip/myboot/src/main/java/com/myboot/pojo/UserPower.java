package com.myboot.pojo;

import lombok.Data;

/**
 * @author hui
 * @date 2023/11/6 10:21
 */
@Data
public class UserPower {
    private Integer id;
    private String name;
    private String zhanghaoguanliAdd;
    private String zhanghaoguanliDel;
    private String zhanghaoguanliUpd;
    private String zhanghaoguanliSel;
    private String quanxianAdd;
    private String quanxianDel;
    private String quanxianUpd;
    private String quanxianSel;
    private String kehuAdd;
    private String kehuDel;
    private String kehuUpd;
    private String kehuSel;
    private String gongyingshangAdd;
    private String gongyingshangUpd;
    private String gongyingshangSel;
    private String shangpinAdd;
    private String shangpinDel;
    private String shangpinUpd;
    private String shangpinSel;
    private String fujiashuiUpd;
    private String peizhiAdd;
    private String peizhiDel;
    private String peizhiUpd;
    private String peizhiSel;
    private String xiaoshouBaojiaAdd;
    private String xiaoshouBaojiaDel;
    private String xiaoshouBaojiaUpd;
    private String xiaoshouBaojiaSel;
    private String xiaoshouDingdanAdd;
    private String xiaoshouDingdanDel;
    private String xiaoshouDingdanSel;
    private String xiaoshouDingdanUpd;
    private String xiaoshouChukuAdd;
    private String xiaoshouChukuDel;
    private String xiaoshouChukuSel;
    private String xiaoshouChukuUpd;
    private String xiaoshouKaipiaoAdd;
    private String xiaoshouKaipiaoDel;
    private String xiaoshouKaipiaoSel;
    private String xiaoshouKaipiaoUpd;
    private String shouruAdd;
    private String shouruUpd;
    private String shouruSel;
    private String shouruDel;
    private String caigouDingdanAdd;
    private String caigouDingdanUpd;
    private String caigouDingdanSel;
    private String caigouDingdanDel;
    private String caigouRukuUpd;
    private String caigouRukuAdd;
    private String caigouRukuSel;
    private String caigouRukuDel;
    private String caigouShoupiaoAdd;
    private String caigouShoupiaoUpd;
    private String caigouShoupiaoDel;
    private String caigouShoupiaoSel;
    private String zhichuUpd;
    private String zhichuAdd;
    private String zhichuSel;
    private String zhichuDel;
    private String zhuanzhangUpd;
    private String zhuanzhangSel;
    private String zhuanzhangAdd;
    private String zhuanzhangDel;
    private String kucunSel;
    private String zhanghuYueSel;
    private String shouruTongjiSel;
    private String zhichuTongjiSel;
    private String yueduTongjiSel;
    private String fujiashuiSel;
}
