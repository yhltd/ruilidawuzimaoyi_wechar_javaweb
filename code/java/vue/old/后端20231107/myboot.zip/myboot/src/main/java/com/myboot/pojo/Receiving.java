package com.myboot.pojo;

import lombok.Data;

@Data
public class Receiving {
    private Integer rId;
    private String rName;
    private String rPhone;
    private String rAddress;
}
