<template>

</template>

<script>
export default {
  name: "JiZhangMingXiType"
}
</script>

<style scoped>

</style>