<template>

</template>

<script>
export default {
  name: "KeHuType"
}
</script>

<style scoped>

</style>