<template>
  <el-container>
    <el-form :inline="true" :model="queryKeyword" class="demo-form-inline">
      <el-form-item label="供应商">
        <el-input v-model="queryKeyword.gongyingshang" placeholder="请输入供应商"></el-input>
      </el-form-item>
      <el-form-item label="日期范围">
        <el-date-picker
            v-model="queryKeyword.dateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="审核状态">
        <el-input v-model="queryKeyword.shenheZhuangtai" placeholder="请输入审核状态"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button @click="fuzzyQuery()">查询</el-button>
      </el-form-item>
    </el-form>
    <el-form :inline="true">
      <el-button size="medium" @click="refresh()"><i class="el-icon-refresh"></i>刷新</el-button>
      <el-button size="medium" @click="addDialog=true">新增</el-button>
      <el-button size="medium" >自己创建的订单</el-button>
      <el-button size="medium" @click="queryNeedShenHe()">可审核的订单</el-button>
    </el-form>
    <br/>
    <el-main>
      <el-table
          border
          :data="tableData"
          style="width: 100%"
          :row-class-name="tableRowClassName"
      >
        <el-table-column width="50">
          <template slot-scope="scope">
            <el-checkbox @click.native="edits(scope.row)"></el-checkbox>
          </template>
        </el-table-column>
        <el-table-column prop="cid" label="订单编号"></el-table-column>
        <el-table-column prop="cname" label="订单日期"></el-table-column>
        <el-table-column prop="cfenl" label="供应商"></el-table-column>
        <el-table-column prop="cboss" label="价税小记"></el-table-column>
        <el-table-column prop="clevel" label="备注"></el-table-column>
        <el-table-column fixed="right" label="操作" width="100">
          <template slot-scope="scope">
            <el-button @click="handleClick(scope.row)" type="text" size="small"
            >编辑
            </el-button
            >
            <el-button type="text" size="small" @click="del(scope.row)"
            >删除
            </el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </el-main>
    <el-footer>
      <div class="page">
        <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage4"
            :page-sizes="[30, 50, 100, 200]"
            :page-size="100"
            background
            layout=" sizes, prev, pager, next"
            :total="1000"
        ></el-pagination>
      </div>
    </el-footer>
    <el-dialog
        title="新建订单"
        :visible.sync="addDialog"
        width="80%"
        :before-close="handleClose">
      <div class="view-box">
        <DingdanAdd></DingdanAdd>
      </div>
    </el-dialog>
  </el-container>
</template>

<script>
import DingdanAdd from './DingDanAdd'
import MessageUtil from "@/utils/MessageUtil";

export default {
  data() {
    return {
      rukus: [
        {
          value: "选项1",
          label: "已入库",
        },
        {
          value: "选项2",
          label: "未入库",
        },
      ],
      ruku: "",
      fukuans: [
        {
          value: "选项1",
          label: "已付款",
        },
        {
          value: "选项2",
          label: "未付款",
        },
      ],
      fukuan: "",
      addDialog: false,
      queryKeyword: {
        dataRange: '',
        gongyingshang: '',
        shenheZhuangtai: ''
      },
      tableData:[],
    }
  },
  methods: {
    refresh() {},
    fuzzyQuery() {
      let url = "http://localhost:8081/caigou/mingxi/fuzzyQuery";
      this.axios.post(url, this.queryKeyword).then(res => {
        if (res.data.code = '00') {
          let data = res.data.data;
          MessageUtil.success("查询到" + data.length + "条数据");
          this.tableData = data;
        } else {
          MessageUtil.error("未查询到任何数据");
        }
      }).cath(() => {
        MessageUtil.error("网络异常")
      });
    },
    /**
     * 会有子页面调用该方法
     *
     * DingDanAdd.vue
     */
    closeDialog() {
      this.addDialog = false;
    }
  },
  components: {DingdanAdd}
};
</script>

<style scoped>
.view-box {
  height: 60vh;
  overflow-y: scroll;
}
</style>
  