<template>

</template>

<script>
export default {
  name: "ShangpinType"
}
</script>

<style scoped>

</style>