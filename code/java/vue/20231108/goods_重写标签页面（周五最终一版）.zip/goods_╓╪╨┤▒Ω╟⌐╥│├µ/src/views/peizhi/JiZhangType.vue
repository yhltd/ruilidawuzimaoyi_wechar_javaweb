<template>

</template>

<script>
export default {
  name: "JiZhangType"
}
</script>

<style scoped>

</style>