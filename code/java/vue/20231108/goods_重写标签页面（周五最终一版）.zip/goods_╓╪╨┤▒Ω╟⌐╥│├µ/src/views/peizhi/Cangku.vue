<template>
<el-container>
  <el-header>
    <el-button @click="" type="primary">添加</el-button>
    <el-button @click="" type="primary">修改</el-button>
    <el-button @click="" type="danger">删除</el-button>
  </el-header>
  <el-main></el-main>
</el-container>
</template>

<script>
export default {
  data() {
    return {
      type: '仓库'
    }
  }
}
</script>

<style scoped>

</style>