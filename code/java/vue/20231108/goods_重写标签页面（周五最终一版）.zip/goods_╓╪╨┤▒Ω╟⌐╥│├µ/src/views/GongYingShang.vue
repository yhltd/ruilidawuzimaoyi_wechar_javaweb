<template>
  <el-container>
    <el-main>
      <el-row :gutter="20">
        <el-col :xs="9" :sm="6" :md="3" :lg="3" :xl="2">
        </el-col>
        <el-col :xs="20" :sm="6" :md="6" :lg="4" :xl="4">
          <el-input placeholder="请输入内容" v-model="keyword" class="input-with-select">
            <el-button slot="append" icon="el-icon-search" @click="fuzzyQuery()"></el-button>
          </el-input>
        </el-col>
        <el-col :xs="5" :sm="3" :md="2" :lg="2" :xl="1.1">
          <el-button size="medium" @click="addDialog">新增</el-button>
        </el-col>
        <el-col :xs="5" :sm="3" :md="2" :lg="2" :xl="1.1">
          <el-button size="medium" @click="updDialog">编辑</el-button>
        </el-col>
        <el-col :xs="5" :sm="3" :md="2" :lg="2" :xl="1.1">
          <el-button size="medium" @click="delUsrList()">删除</el-button>
        </el-col>
        <el-col :xs="6" :sm="3" :md="2" :lg="2" :xl="1.1">
          <el-button size="medium" @click="exportExcel()">导出Excel</el-button>
        </el-col>
      </el-row>
      <br>
      <el-table
          border
          :data="tableData"
          style="width: 100%"
          @selection-change="handleSelectionChange"
      >
        <el-table-column
            type="selection"
            width="55">
        </el-table-column>
        <el-table-column width="50" hidden>
        </el-table-column>
        <el-table-column prop="bianhao" label="客户编号"></el-table-column>
        <el-table-column prop="name" label="客户名称"></el-table-column>
        <el-table-column prop="gongyingshangDengji" label="供应商等级"></el-table-column>
        <el-table-column prop="suozaiDiqu" label="所在地区"></el-table-column>
        <el-table-column prop="dizhi" label="地址"></el-table-column>
        <el-table-column prop="beizhu" label="备注"></el-table-column>
        <el-table-column prop="shoujianName" label="收件人"></el-table-column>
        <el-table-column prop="shoujianPhone" label="收件电话"></el-table-column>
      </el-table>
    </el-main>
  </el-container>
</template>

<script>
export default {
  data() {
    return {
      tableData: [
        {
          id: '',
          bianhao: '',
          name: '',
          gongyingshangDengji: '',
          suozaiDiqu: '',
          dizhi: '',
          beizhu: '',
          shoujianName: '',
          shoujianPhone: '',
        }
      ],
      tableCheckList: [],
    }
  },
  methods: {
    toggleSelection(rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      } else {
        this.$refs.multipleTable.clearSelection();
      }
    },

    handleSelectionChange(val) {
      this.tableCheckList = val;
    },
  }
}
</script>

<style scoped>

</style>